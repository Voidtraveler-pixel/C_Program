#include <stdio.h>

int main() {
    // \n moves the cursor to the beginning of the next line
    printf("Hello\nWorld\nC Programming\n");
    return 0;
}