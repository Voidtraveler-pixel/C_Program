#include <stdio.h>

int main() {
    // \t inserts a horizontal tab space
    printf("Roll\tName\tMarks\n");
    printf("1\tRaj\t85\n");    
    printf("2\tSita\t90\n");   
    printf("3\tJohn\t78\n");  
    return 0;
}