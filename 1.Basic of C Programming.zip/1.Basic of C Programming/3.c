#include <stdio.h>

int main() {
    // \r moves the cursor to the beginning of the current line, 
    // overwriting the existing characters with the new ones.
    // By adding spaces after "Hi", we overwrite the rest of "Hello".
    printf("Hello World\rHi   \n");
    return 0;
}