#include <stdio.h>

int main() {
    // \b moves the cursor one position back, causing the 'o' in Hello 
    // to be overwritten by the space before "World".
    printf("Hello\b World\n");
    return 0;
}