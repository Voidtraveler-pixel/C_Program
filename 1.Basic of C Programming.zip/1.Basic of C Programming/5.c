#include <stdio.h>

int main() 
{
    printf("Student Report\n");

    printf("\tName: Rajib\n");

    printf("\tSubject:  \bC Programming\n");

    printf("Loading marks...\r\tMarks: 90\n");
    
    return 0;
}