#include <stdio.h>

int main() {
    printf("********************\n");           
    printf("** BILL      **\n");           
    printf("********************\n");
  
    printf("Item\t\tQty\tPrice\n");           
    printf("--------------------------------\n");
   
    printf("Pen\t\t2\t20\n");               
    printf("Notebook\t1\t50\n");            
    printf("--------------------------------\n");
    
    printf("Total:\t\t\t90\n");          
    printf("********************\n");
    
    return 0;
}