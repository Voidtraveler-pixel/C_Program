#include <stdio.h>
#include <stdlib.h>

int main() 
{
    int n, i, *ptr;

    // Prompt the user for the number of elements
    printf("Enter the number of elements: ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Invalid input. Please enter a positive integer.\n");
        return 1;
    }

    // Allocate memory for n integers using calloc()
    // calloc() initializes the allocated memory to zero
    ptr = (int*) calloc(n, sizeof(int));

    // Check if memory allocation was successful
    if (ptr == NULL) {
        printf("Memory allocation failed!\n");
        return 1;
    }

    // Display the initialized values (which are all 0)
    printf("\nInitialized values of the allocated memory block:\n");
    for (i = 0; i < n; i++) {
        // Accessing the elements using pointer arithmetic: *(ptr + i)
        printf("ptr[%d] = %d\n", i, *(ptr + i));
    }

    // Free the allocated memory
    free(ptr);
    printf("\nMemory freed successfully.\n");

    return 0;
}