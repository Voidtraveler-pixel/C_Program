#include<stdio.h>
#include<conio.h>

#define add1(x,y) x+y
#define add2(x,y) (x+y)
#define big(a,b)  (a>b)?a:b

int main()
{

int c,d,max;
c=add1(2,3)*5;
d=add2(2,3)*5;
max=big(c,d);

printf("\nc=%d",c);

printf("\nd=%d",d);

printf("\nMaximum=%d",max);

printf("\nMaximum=%d",big(c,d));


getch();
return 0;
}