#include <stdio.h>

int main() 
{
    int a, b, c;
    a = b = c = 5;

    printf("After the chained assignment a = b = c = 5;\n");
    printf("a = %d\n", a);
    printf("b = %d\n", b);
    printf("c = %d\n", c);

    int x = 10, y = 20, z = 30;

    x = y = z + 10;
    printf("\nAfter the chained assignment x = y = z + 10;\n");
    printf("x = %d\n", x);
    printf("y = %d\n", y);
    printf("z = %d\n", z); 
    return 0;
}
