#include <stdio.h>

int main() 
{
    int i;
    printf("Loop starts:\n");
    for (i = 1; i <= 10; i++) 
    {        
        if (i == 5) 
        {
            printf("(Skipping 5 using continue)\n");
            continue;
        }
        if (i == 9) 
        {
            printf("(Stopping at 9 using break)\n");
            break; 
        }
        printf("Number: %d\n", i);
    }
    printf("Loop ended.\n");
    return 0;
}