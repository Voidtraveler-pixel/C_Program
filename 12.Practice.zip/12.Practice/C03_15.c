#include <stdio.h>

int main() 
{
    int rows, i, j, number = 1;
    rows = 4;
    printf("Floyd's Triangle:\n");
    for (i = 1; i <= rows; i++) 
    {        
        for (j = 1; j <= i; j++) 
        {
            printf("%d ", number);
            number++;
        }     
        printf("\n");
    }
    return 0;
}