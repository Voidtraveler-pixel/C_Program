#include <stdio.h>
#include <math.h>

int main() 
{
    int num, o, r, i = 0;
    float result = 0.0;

    printf("Enter an integer: ");
    scanf("%d", &num);
    for (o = num; o != 0; o /= 10) 
    {
        i++;
    }

    for (o = num; o!= 0; o /= 10) 
    {
        r = o % 10;
        result += pow(r, i);
    }

    if ((int)result == num)
        printf("%d is an Armstrong number.\n", num);
    else
        printf("%d is not an Armstrong number.\n", num);

    return 0;
}