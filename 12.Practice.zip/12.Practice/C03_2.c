#include <stdio.h>

int main() 
{
    int n, i;
    long fact = 1; 
    printf("Enter an integer: ");
    scanf("%d", &n);
    if (n < 0) 
    {
        printf("Error! \n");
    }
    else 
        {
        for (i = 1; i <= n; ++i)
         {
            fact *= i;            
        }
        printf("Factorial of %d = %l\n", n, fact);
    }
    return 0;
}