#include <stdio.h>

int main() 
{
    int units;
    float total_bill = 0;

    printf("Enter total units consumed: ");
    scanf("%d", &units);
    switch(units / 100) 
    {
        case 1:
            total_bill = units * 5.0;
            break;
        case 2: // 100 to 199 units
            // First 100 units @ 5, remaining @ 7
            total_bill = (100 * 5.0) + (units - 100) * 7.0;
            break;
        case 3: // 200 to 299 units
            // First 100 @ 5, next 100 @ 7, remaining @ 9
            total_bill = (100 * 5.0) + (100 * 7.0) + (units - 200) * 9.0;
            break;
        case 4: // 300 units and above
            // First 100 @ 5, next 100 @ 7, next 100 @ 9, remaining @ 10
            total_bill = (100 * 5.0) + (100 * 7.0) + (100 * 9.0) + (units - 300) * 10.0;
    }
    printf("Total Electricity Bill: Rs. %.2f\n", total_bill);
    return 0;
}