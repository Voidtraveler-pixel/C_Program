#include <stdio.h>
#include <math.h> 

int main() {
    double a, b, c, discriminant, root1, root2, realPart, imagPart;

    printf("Enter coefficients a, b and c: ");
    scanf("%lf %lf %lf", &a, &b, &c);
    discriminant = b * b - 4 * a * c;

    switch (discriminant > 0) 
    {

    case 1:
        root1 = (-b + sqrt(discriminant)) / (2 * a);
        root2 = (-b - sqrt(discriminant)) / (2 * a);
        printf("Roots are real and distinct:\n");
        printf("Root 1 = %.2lf\n", root1);
        printf("Root 2 = %.2lf\n", root2);
        break;

    case 0:
        switch (discriminant == 0) 
        {
            case 1:
                root1 = root2 = -b / (2 * a);
                printf("Roots are real and equal:\n");
                printf("Root 1 = Root 2 = %.2lf\n", root1);
                break;
            case 0:
                realPart = -b / (2 * a);
                imagPart = sqrt(-discriminant) / (2 * a);
                printf("Roots are complex and imaginary:\n");
                printf("Root 1 = %.2lf + %.2lfi\n", realPart, imagPart);
                printf("Root 2 = %.2lf - %.2lfi\n", realPart, imagPart);
                break;
        }
        break;
    }
    return 0;
}