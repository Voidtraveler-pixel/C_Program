#include <stdio.h>

int findGCD(int a, int b) 
{
    if (b == 0) 
    return a;
    return findGCD(b, a % b);
}
int findLCM(int a, int b) 
{
    if (a == 0 || b == 0) 
    return 0;
    return (a * b) / findGCD(a, b);
}
int main() 
{
    int n1, n2;
    printf("Enter two integers: ");
    scanf("%d %d", &n1, &n2);   
    printf("LCM of %d and %d is %d\n", n1, n2, findLCM(n1, n2));
    return 0;
}