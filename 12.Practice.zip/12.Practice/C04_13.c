#include <stdio.h>

void reverseArray(int arr[], int start, int end) 
{
    int temp;
    while (start < end) 
    {
        temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;
        start++;
        end--;
    }
}
int main() 
{
    int n;
    printf("Enter size of array: ");
    scanf("%d", &n);


    int arr[n];
    printf("Enter elements: ");

    for(int i = 0; i < n; i++) 
    scanf("%d", &arr[i]);
    reverseArray(arr, 0, n-1);
    printf("Reversed Array: ");
 
   for(int i = 0; i < n; i++) 
    printf("%d ", arr[i]);
    printf("\n");
    return 0;
}