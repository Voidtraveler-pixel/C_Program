#include <stdio.h>
#include <string.h>

int countWords(char str[]) 
{
    int count = 0;
    int inWord = 0; 
    
    for (int i = 0; str[i] != '\0'; i++)
    {
        if (str[i] != ' ' && str[i] != '\n' && str[i] != '\t') 
        {
            if (inWord == 0) 
            {
                count++;
                inWord = 1;
            }
        }
        else 
        {
            inWord = 0;
        }
    }
    return count;
}
int main() 
{
    char str[100];
    printf("Enter a sentence: ");
    scanf(" %[^\n]s", str); 
    printf("Total words: %d\n", countWords(str));
    return 0;
}