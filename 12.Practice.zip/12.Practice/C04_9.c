#include <stdio.h>
void calculateSums(int arr[], int size, int evenSum, int oddSum) {
    evenSum = 0;
    oddSum = 0;
    for (int i = 0; i < size; i++) 
    {
        if (arr[i] % 2 == 0)
         {
            evenSum += arr[i];
        } else 
        {
            oddSum += arr[i];
        }
    }
}
int main()
{
    int n, i;
    int arr[100]; 
    int eTotal, oTotal; 
    printf("Enter the number of elements (max 100): ");
    scanf("%d", &n);
    printf("Enter %d integers:\n", n);
    for (i = 0; i < n; i++) 
    {
        scanf("%d", &arr[i]);
    }
    calculateSums(arr, n, &eTotal, &oTotal);
    printf("Sum of Even numbers: %d\n", eTotal);
    printf("Sum of Odd numbers:  %d\n", oTotal);
    return 0;
}