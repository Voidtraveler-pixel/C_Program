#include <stdio.h>

char ones[] = {"", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
char teens[] = {"ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"};
char tens[] = {"", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"};

void convertToWords(int n) 
{
    if (n >= 1000) 
    {
        printf("%s thousand ", ones[n / 1000]);
        n %= 1000;
    }
    if (n >= 100) 
    {
        printf("%s hundred ", ones[n / 100]);
        n %= 100;
    }
    if (n >= 20) 
    {
        printf("%s ", tens[n / 10]);
        n %= 10;
    }
    if (n >= 10 && n <= 19) 
    {
        printf("%s ", teens[n - 10]);
        n = 0;
    }
    if (n > 0) 
    {
        printf("%s ", ones[n]);
    }
}

int main() 
{
    int num;
    printf("Enter a number (0-9999): ");
    scanf("%d", &num);
    if (num == 0) 
    printf("zero");
    else 
    convertToWords(num);
    printf("\n");
    return 0;
}