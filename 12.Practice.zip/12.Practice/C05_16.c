#include <stdio.h>

int main() 
{
    int r, c, i, j, isSymmetric = 1;
    // 1. Input dimensions
    printf("Enter number of rows and columns: ");
    scanf("%d %d", &r, &c);
    // 2. Check if it is a square matrix
    if (r != c) 
    {
        printf("Error: A symmetric matrix must be a square matrix (rows = columns).\n");
        return 0;
    }
    int matrix[r][c];
    // 3. Input matrix elements
    printf("Enter elements of the matrix:\n");
    for (i = 0; i < r; i++) 
    {
        for (j = 0; j < c; j++) 
        {
            printf("Element [%d][%d]: ", i, j);
            scanf("%d", &matrix[i][j]);
        }
    }
    // 4. Check for symmetry
    // We only need to check the upper triangle against the lower triangle
    for (i = 0; i < r; i++) 
    {
        for (j = 0; j < c; j++)
        {
            if (matrix[i][j] != matrix[j][i]) 
            {
                isSymmetric = 0; // Found a mismatch
                break;
            }
        }
        if (isSymmetric == 0) 
        break; // Break outer loop if mismatch found
    }
    // 5. Output result
    if (isSymmetric) 
    {
        printf("\nThe matrix is Symmetric.\n");
    } 
    else 
    {
        printf("\nThe matrix is NOT Symmetric.\n");
    }

    return 0;
}