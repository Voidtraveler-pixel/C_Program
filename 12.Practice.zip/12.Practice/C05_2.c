#include <stdio.h>

int main() 
{
    int n, pos, val, i;

    printf("Enter number of elements: ");
    scanf("%d", &n);
    int arr[n + 1]; // Extra space for new element

    printf("Enter %d elements: ", n);
    for(i = 0; i < n; i++) scanf("%d", &arr[i]);

    printf("Enter position to insert (1 to %d) and value: ", n + 1);
    scanf("%d %d", &pos, &val);

    // Shift elements to the right
    for(i = n; i >= pos; i--) 
    {
        arr[i] = arr[i - 1];
    }
    arr[pos - 1] = val; // Insert value
    n++; // Increase size

    printf("Array after insertion: ");
    for(i = 0; i < n; i++) printf("%d ", arr[i]);
    printf("\n");
    return 0;
}