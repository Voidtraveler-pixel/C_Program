#include <stdio.h>

int main() 
{
    int n1, n2, i, k = 0;

    printf("Enter size of first array: ");
    scanf("%d", &n1);
    int arr1[n1];
    printf("Enter elements for first array: ");
    for(i = 0; i < n1; i++) scanf("%d", &arr1[i]);

    printf("Enter size of second array: ");
    scanf("%d", &n2);
    int arr2[n2];
    printf("Enter elements for second array: ");
    for(i = 0; i < n2; i++) scanf("%d", &arr2[i]);

    int merged[n1 + n2];
    for(i = 0; i < n1; i++) 
    merged[k++] = arr1[i];
    for(i = 0; i < n2; i++)
     merged[k++] = arr2[i];

    printf("Merged Array: ");
    for(i = 0; i < n1 + n2; i++) printf("%d ", merged[i]);
    printf("\n");
    return 0;
}