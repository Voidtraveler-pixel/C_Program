#include <stdio.h>
#include <string.h>

int main() 
{
    int n, i;
    char combined[1000] = ""; // Large buffer
    char temp[100];

    printf("Enter number of words/strings to combine: ");
    scanf("%d", &n);

    printf("Enter the strings:\n");
    for(i = 0; i < n; i++) 
    {
        scanf("%s", temp);
        strcat(combined, temp);
        strcat(combined, " "); // Add space between words
    }

    printf("Combined Sentence: %s\n", combined);
    return 0;
}