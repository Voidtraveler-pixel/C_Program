#include <stdio.h>
#include <string.h>

int main() 
{
    int n, i, j;
    printf("Enter number of strings: ");
    scanf("%d", &n);
    char words[n][50]; 
    printf("Enter words:\n");
    for(i = 0; i < n; i++) 
    scanf("%s", words[i]);
    printf("Duplicate strings are: ");
    int found = 0;
    for(i = 0; i < n; i++) 
    {
        for(j = i + 1; j < n; j++) 
        {
            if(strcmp(words[i], words[j]) == 0) 
            {
                printf("%s ", words[i]);
                found = 1;
                break;
            }
        }
    }
    if(!found) 
    printf("None");
    printf("\n");
    return 0;
}