#include <stdio.h>
int linearSearch(int arr[], int n, int key) 
{
    for(int i = 0; i < n; i++) 
    {
        if(arr[i] == key) 
        return i; 
    }
    return -1;
}
int main() 
{
    int n, key;
    printf("Enter size: ");
    scanf("%d", &n);
    int arr[n];
    printf("Enter elements: ");
    for(int i = 0; i < n; i++) 
    scanf("%d", &arr[i]);
    printf("Enter value to search: ");
    scanf("%d", &key);
    int result = linearSearch(arr, n, key);
    if(result != -1) 
    printf("Element found at position %d\n", result+1);
    else 
    printf("Element not found\n");
    return 0;
}