#include <stdio.h>

struct BankAccount 
{
    int accountNumber;
    char name[50];
    float balance;
};
void deposit(struct BankAccount *acc, float amount) 
{
    acc->balance += amount;
    printf("\nSuccess! %.2f deposited.", amount);
    printf("\nNew Balance: %.2f\n", acc->balance);
}
void withdraw(struct BankAccount *acc, float amount) 
{
    if (amount > acc->balance) 
    {
        printf("\nError!\n");
    } 
    else 
    {
        acc->balance -= amount;
        printf("\nSuccess! %.2f withdrawn.", amount);
        printf("\nNew Balance: %.2f\n", acc->balance);
    }
}
void balanceEnquiry(struct BankAccount acc) 
{
    printf("\n--- Account Details ---");
    printf("\nAccount No: %d", acc.accountNumber);
    printf("\nName: %s", acc.name);
    printf("\nCurrent Balance: %.2f\n", acc.balance);
}
int main() 
{
    struct BankAccount myAccount;
    int choice;
    float amount;
    printf("--- Create New Account ---\n");
    printf("Enter Account Number: ");
    scanf("%d", &myAccount.accountNumber);
    printf("Enter Account Holder Name: ");
    scanf("%s", myAccount.name); 
    printf("Enter Initial Balance: ");
    scanf("%f", &myAccount.balance);
    do {
        printf("\n\n--- Bank Menu ---\n");
        printf("1. Deposit\n");
        printf("2. Withdraw\n");
        printf("3. Balance Enquiry\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch(choice) 
        {
            case 1:
                printf("Enter amount to deposit: ");
                scanf("%f", &amount);
                if(amount > 0)
                    deposit(&myAccount, amount); // Pass address
                else
                    printf("Invalid amount!\n");
                break;
            
            case 2:
                printf("Enter amount to withdraw: ");
                scanf("%f", &amount);
                if(amount > 0)
                    withdraw(&myAccount, amount); // Pass address
                else
                    printf("Invalid amount!\n");
                break;
            
            case 3:
                balanceEnquiry(myAccount); // Pass value (read-only)
                break;
            
            case 4:
                printf("Exiting... Thank you!\n");
                break;
            
            default:
                printf("Invalid choice! Please try again.\n");
        }
    } while (choice != 4);
    return 0;
}