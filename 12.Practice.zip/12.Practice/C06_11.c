#include <stdio.h>
struct Movie 
{
    char title[100];
    char genre[50];
    float rating;
    int year;
};
int main() 
{
    int n, i, bestIndex = 0;
    printf("Enter the number of movies: ");
    scanf("%d", &n);
    struct Movie movies[n];
    for (i = 0; i < n; i++) 
    {
        printf("\nEnter details for Movie %d:\n", i + 1);
        printf("Title: ");
        scanf(" %[^\n]s", movies[i].title);
        printf("Genre: ");
        scanf(" %[^\n]s", movies[i].genre);
        printf("Year: ");
        scanf("%d", &movies[i].year);
        printf("Rating (0.0 - 10.0): ");
        scanf("%f", &movies[i].rating);
    }
    for (i = 1; i < n; i++) 
    {
        if (movies[i].rating > movies[bestIndex].rating) 
        {
            bestIndex = i;
        }
    }
    printf("       BEST RATED MOVIE\n\n");
    printf("Title  : %s\n", movies[bestIndex].title);
    printf("Genre  : %s\n", movies[bestIndex].genre);
    printf("Year   : %d\n", movies[bestIndex].year);
    printf("Rating : %.1f/10.0\n", movies[bestIndex].rating);
    return 0;
}