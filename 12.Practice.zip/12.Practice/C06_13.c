#include <stdio.h>

struct StudentRecord 
{
    char name[50];
    int roll;
    int age;
    char address[100];
};
int main() 
{
    struct StudentRecord student;
    struct StudentRecord *ptr;
    ptr = &student;
    printf("--- Enter Student Personal Record ---\n");
    printf("Enter Name: ");
    scanf(" %[^\n]s", ptr->name); 
    printf("Enter Roll Number: ");
    scanf("%d", &ptr->roll);
    printf("Enter Age: ");
    scanf("%d", &ptr->age);
    printf("Enter Address: ");
    scanf(" %[^\n]s", ptr->address);
    printf("\n--- Displaying Record via Pointer ---\n");
    printf("Name    : %s\n", ptr->name);
    printf("Roll No : %d\n", ptr->roll);
    printf("Age     : %d\n", ptr->age);
    printf("Address : %s\n", ptr->address);
    return 0;
}