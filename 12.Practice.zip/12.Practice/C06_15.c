#include <stdio.h>
#include <stdlib.h> // For exit()

int main() 
{
    FILE *sourceFile, *targetFile;
    char sourceName[100], targetName[100];
    char ch;
    printf("Enter the name of the source file to copy from: ");
    scanf("%s", sourceName);
    printf("Enter the name of the target file to copy to: ");
    scanf("%s", targetName);
    sourceFile = fopen(sourceName, "r");
    if (sourceFile == NULL) 
    {
        printf("Error");
        exit(0);
    }
    targetFile = fopen(targetName, "w");
    if (targetFile == NULL) 
    {
        printf("Error");
        fclose(sourceFile);
        exit(0);
    }
    printf("Copying file...\n");
    while ((ch = fgetc(sourceFile)) != EOF) 
    {
        fputc(ch, targetFile);
    }
    printf("Success! Content copied from %s to %s.\n", sourceName, targetName);
    fclose(sourceFile);
    fclose(targetFile);
    return 0;
}