#include <stdio.h>
#include <stdlib.h>

int main() 
{
    FILE *fp;
    char filename[100];
    char searchChar, ch;
    int count = 0;
    printf("Enter the filename to read: ");
    scanf("%s", filename);
    printf("Enter the character to count: ");
    scanf(" %c", &searchChar);
    fp = fopen(filename, "r");
    if (fp == NULL) 
    {
        printf("Error: Could not open file '%s'.\n", filename);
        exit(0);
    }
    while ((ch = fgetc(fp)) != EOF) 
    {
        if (ch == searchChar) 
        {
            count++;
        }
    }
    printf("The character '%c' appears %d times in the file.\n", searchChar, count);
    fclose(fp);
    return 0;
}