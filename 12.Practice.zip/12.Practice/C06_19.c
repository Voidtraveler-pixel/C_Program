#include <stdio.h>
#include <string.h>
typedef struct StudentDetails 
{
    char name[50];
    int roll;
    float marks;
} 
Student;
void display(Student s[], int n) 
{
    printf("\n%-20s %-10s %-10s\n", "Name", "Roll No", "Marks");
    for (int i = 0; i < n; i++) 
    {
        printf("%-20s %-10d %-10.2f\n", s[i].name, s[i].roll, s[i].marks);
    }
}
void sortStudents(Student s[], int n, int criteria) 
{
    Student temp;
    for (int i = 0; i < n - 1; i++) 
    {
        for (int j = 0; j < n - i - 1; j++) 
        {
            int swap = 0; 
            if (criteria == 1) 
            { 
                if (strcmp(s[j].name, s[j+1].name) > 0)
                    swap = 1;
            } 
            else if (criteria == 2) 
            { 
                if (s[j].roll > s[j+1].roll)
                    swap = 1;
            } 
            else if (criteria == 3) 
            { 
                if (s[j].marks < s[j+1].marks)
                    swap = 1;
            }
            if (swap) 
            {
                temp = s[j];
                s[j] = s[j+1];
                s[j+1] = temp;
            }
        }
    }
}
int main() 
{
    int n, i, choice;
    printf("Enter the number of students: ");
    scanf("%d", &n);
    Student s[n]; 
    for (i = 0; i < n; i++) 
    {
        printf("\nEnter details for Student %d:\n", i + 1);
        printf("Name: ");
        scanf(" %[^\n]s", s[i].name); 
        printf("Roll No: ");
        scanf("%d", &s[i].roll);
        printf("Marks: ");
        scanf("%f", &s[i].marks);
    }
    do 
    {
        printf("\n--- SORTING MENU ---\n");
        printf("1. Sort by Name (A-Z)\n");
        printf("2. Sort by Roll Number (Ascending)\n");
        printf("3. Sort by Marks (High to Low)\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice) 
        {
            case 1:
                sortStudents(s, n, 1);
                printf("\n--- List Sorted by Name ---\n");
                display(s, n);
                break;
            case 2:
                sortStudents(s, n, 2);
                printf("\n--- List Sorted by Roll Number ---\n");
                display(s, n);
                break;
            case 3:
                sortStudents(s, n, 3);
                printf("\n--- List Sorted by Marks ---\n");
                display(s, n);
                break;
            case 4:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    } 
    while (choice != 4);
    return 0;
}