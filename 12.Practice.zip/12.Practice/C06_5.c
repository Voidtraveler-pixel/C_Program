#include <stdio.h>
struct Date 
{
    int day;
    int month;
    int year;
};
int compareDates(struct Date d1, struct Date d2) 
{
    if (d1.year < d2.year)
        return -1; 
    else if (d1.year > d2.year)
        return 1;  
    if (d1.month < d2.month)
        return -1;
    else if (d1.month > d2.month)
        return 1;
    if (d1.day < d2.day)
        return -1;
    else if (d1.day > d2.day)
        return 1;
    return 0;
}
int main() 
{
    struct Date date1, date2;
    int result;
    printf("Enter first date (DD MM YYYY): ");
    scanf("%d %d %d", &date1.day, &date1.month, &date1.year);
    printf("Enter second date (DD MM YYYY): ");
    scanf("%d %d %d", &date2.day, &date2.month, &date2.year);
    result = compareDates(date1, date2);
    if (result == -1) 
    {
        printf("\nDate 1 (%d/%d/%d) comes earlier.\n", date1.day, date1.month, date1.year);
    } 
    else if 
    (result == 1) 
    {
        printf("\nDate 2 (%d/%d/%d) comes earlier.\n", date2.day, date2.month, date2.year);
    } 
    else 
    {
        printf("\nBoth dates are the same.\n");
    }
    return 0;
}