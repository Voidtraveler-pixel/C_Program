#include <stdio.h>
struct Student 
{
    char name[50];
    int roll;
    float marks;
};
struct Student findTopper(struct Student s[], int n) 
{
    struct Student max = s[0];
    
    for (int i = 1; i < n; i++) 
    {
        if (s[i].marks > max.marks) 
        {
            max = s[i];
        }
    }
    return max; 
}
int main() 
{
    int n, i;
    printf("Enter the number of students: ");
    scanf("%d", &n);
    struct Student s[n];
    for (i = 0; i < n; i++) 
    {
        printf("\nEnter details for Student %d:\n", i + 1);
        printf("Name: ");
        scanf("%s", s[i].name); 
        printf("Roll Number: ");
        scanf("%d", &s[i].roll);
        printf("Marks: ");
        scanf("%f", &s[i].marks);
    }
    struct Student topper = findTopper(s, n);
    printf("Student with the Highest Marks:\n");
    printf("Name: %s\n", topper.name);
    printf("Roll: %d\n", topper.roll);
    printf("Marks: %.2f\n", topper.marks);
    return 0;
}