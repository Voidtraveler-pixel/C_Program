#include <stdio.h>
struct Item 
{
    int itemCode;
    char itemName[50];
    int quantity;
    float price;
};
int main() 
{
    int n, i;
    float totalValue = 0.0;
    printf("Enter the number of items to add to inventory: ");
    scanf("%d", &n);
    struct Item inventory[n];
    for (i = 0; i < n; i++) 
    {
        printf("\nEnter details for Item %d:\n", i + 1);
        printf("Item Code: ");
        scanf("%d", &inventory[i].itemCode);
        printf("Item Name: ");
        scanf("%s", inventory[i].itemName); 
        printf("Quantity: ");
        scanf("%d", &inventory[i].quantity);
        printf("Price per unit: ");
        scanf("%f", &inventory[i].price);
    }
    printf("%-10s %-20s %-10s %-10s %-10s\n", "Code", "Name", "Qty", "Price", "Value");
    for (i = 0; i < n; i++) 
    {
        float itemTotal = inventory[i].quantity * inventory[i].price;
        totalValue += itemTotal;
        printf("%-10d %-20s %-10d %-10.2f %-10.2f\n", 
               inventory[i].itemCode, 
               inventory[i].itemName, 
               inventory[i].quantity, 
               inventory[i].price, 
               itemTotal);
    }    
    printf("Total Inventory Value: %.2f\n", totalValue);
    return 0;
}