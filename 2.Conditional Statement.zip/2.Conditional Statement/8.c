#include <stdio.h>

int main() 
{
    float units, bill = 0.0;
    
    printf("Enter the number of units consumed: ");
    scanf("%f", &units);
    
    if (units <= 100)
    {
        bill = units * 25.0;
    } 
    else if (units <= 300) 
    {
        bill = (100 * 25.0) + ((units - 100) * 27.0);
    } 
    else 
    {
        bill = (100 * 25.0) + (200 * 27.0) + ((units - 300) * 10.0);
    }
    printf("Total Electricity Bill: %.2f\n", bill);
    return 0;
}