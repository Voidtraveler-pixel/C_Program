#include <stdio.h>

int main()
 {
    int choice;
    float balance = 0.0, amount;

    do {
        printf("\n--- Banking System Menu ---\n");
        printf("1. Deposit\n");
        printf("2. Withdraw\n");
        printf("3. Check Balance\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch(choice) 
        {
            case 1:
                printf("Enter amount to deposit: ");
                scanf("%f", &amount);
                if (amount > 0) 
                {
                    balance += amount;
                    printf("Successfully deposited Rs. %.2f\n", amount);
                } 
                else 
                {
                    printf("Invalid amount!\n");
                }
                break;
            case 2:
                printf("Enter amount to withdraw: ");
                scanf("%f", &amount);
                if (amount > 0 && amount <= balance) 
                {
                    balance -= amount;
                    printf("Successfully withdrew Rs. %.2f\n", amount);
                } 
                else if (amount > balance)
                 {
                    printf("Insufficient balance!\n");
                }
                 else
                  {
                    printf("Invalid amount!\n");
                }
                break;
            case 3:
                printf("Current Balance: Rs. %.2f\n", balance);
                break;
            case 4:
                printf("Thank you for using the Banking System. Goodbye!\n");
                break;
            default:
                printf("Invalid choice! Please select between 1 and 4.\n");
        }
    } while (choice != 4);

    return 0;
}