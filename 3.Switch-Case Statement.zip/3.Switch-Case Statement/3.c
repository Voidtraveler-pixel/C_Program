#include <stdio.h>
#include <ctype.h>

int main() 
{
    char ch;
    printf("Enter an alphabet: ");
    scanf(" %c", &ch);
    char lower_ch = tolower(ch);
    if (isalpha(ch))
     {
        switch(lower_ch)
         {
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
                printf("%c is a Vowel.\n", ch);
                break;
            default:
                printf("%c is a Consonant.\n", ch);
        }
    } 
    else 
    {
        printf("Invalid input! Please enter an alphabet.\n");
    }
    return 0;
}