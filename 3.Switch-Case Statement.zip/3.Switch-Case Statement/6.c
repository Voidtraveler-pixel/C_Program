#include <stdio.h>

int main() 
{
    int choice;
    float temp, converted;

    printf("Temperature Conversion Menu:\n");
    printf("1. Celsius to Fahrenheit\n");
    printf("2. Fahrenheit to Celsius\n");
    printf("Enter your choice (1-2): ");
    scanf("%d", &choice);

    switch(choice)
     {
        case 1:
            printf("Enter temperature in Celsius: ");
            scanf("%f", &temp);
            converted = (temp * 9.0 / 5.0) + 32;
            printf("%.2f Celsius = %.2f Fahrenheit\n", temp, converted);
            break;
        case 2:
            printf("Enter temperature in Fahrenheit: ");
            scanf("%f", &temp);
            converted = (temp - 32) * 5.0 / 9.0;
            printf("%.2f Fahrenheit = %.2f Celsius\n", temp, converted);
            break;
        default:
            printf("Invalid choice!\n");
    }
    return 0;
}