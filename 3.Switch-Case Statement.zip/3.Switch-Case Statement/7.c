#include <stdio.h>
#include <ctype.h>

int main() 
{
    char color;
    printf("Enter traffic light color (R for Red, Y for Yellow, G for Green): ");
    scanf(" %c", &color);

    switch(toupper(color)) 
    {
        case 'R':
            printf("STOP!\n");
            break;
        case 'Y':
            printf("READY / CAUTION!\n");
            break;
        case 'G':
            printf("GO!\n");
            break;
        default:
            printf("Invalid color code.\n");
    }
    return 0;
}