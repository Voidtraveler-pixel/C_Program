#include <stdio.h>

int main() 
{
    int type;
    float units, bill;

    printf("Electricity Bill Calculator\n");
    printf("1. Domestic (Rs. 5/unit)\n");
    printf("2. Commercial (Rs. 8/unit)\n");
    printf("3. Industrial (Rs. 12/unit)\n");
    printf("Enter customer type (1-3): ");
    scanf("%d", &type);

    if(type >= 1 && type <= 3) 
    {
        printf("Enter units consumed: ");
        scanf("%f", &units);
    }

    switch(type) 
    {
        case 1:
            bill = units * 5.0;
            printf("Domestic Electricity Bill: Rs. %.2f\n", bill);
            break;
        case 2:
            bill = units * 8.0;
            printf("Commercial Electricity Bill: Rs. %.2f\n", bill);
            break;
        case 3:
            bill = units * 12.0;
            printf("Industrial Electricity Bill: Rs. %.2f\n", bill);
            break;
        default:
            printf("Invalid customer type.\n");
    }
    return 0;
}