#include <stdio.h>

int main() 
{
    int marks;
    printf("Enter marks (0-100): ");
    scanf("%d", &marks);

    if(marks < 0 || marks > 100) 
    {
        printf("Invalid marks!\n");
        return 1;
    }

    switch(marks / 10) 
    {
        case 10: 
        case 9:
            printf("Grade: A\n"); // 90-100
            break;
        case 8:
            printf("Grade: B\n"); // 80-89
            break;
        case 7:
            printf("Grade: C\n"); // 70-79
            break;
        case 6:
            printf("Grade: D\n"); // 60-69
            break;
        default:
            printf("Grade: F\n"); // Below 60
    }
    return 0;
}