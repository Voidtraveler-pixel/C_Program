#include <stdio.h>
int main() 
{
    int n, i;
    printf("Enter N: ");
    scanf("%d", &n);
    printf("Reverse Counting: ");
    for(i = n; i >= 1; i--) 
    {
        printf("%d ", i);
    }
    return 0;
}