#include <stdio.h>
int main() 
{
    int n, i, a = 0, b = 1, c = 1, d;
    printf("Enter N: ");
    scanf("%d", &n);
    printf("Tribonacci: ");
    for(i=1; i<=n; i++) 
    {
        printf("%d ", a);
        d = a + b + c;
        a = b;
        b = c;
        c = d;
    }
    return 0;
}