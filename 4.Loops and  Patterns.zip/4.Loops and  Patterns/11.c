#include <stdio.h>

int main() {
    int n, i, j, k;

    // Pattern A: Square of stars
    n = 5;
    printf("Pattern A:\n");
    for(i=1; i<=n; i++) {
        for(j=1; j<=n; j++) printf("*");
        printf("\n");
    }

    // Pattern B: Right Triangle
    printf("\nPattern B:\n");
    for(i=1; i<=n; i++) {
        for(j=1; j<=i; j++) printf("*");
        printf("\n");
    }

    // Pattern C: Mirrored Right Triangle
    printf("\nPattern C:\n");
    for(i=1; i<=n; i++) {
        for(j=1; j<=n-i; j++) printf(" ");
        for(k=1; k<=i; k++) printf("*");
        printf("\n");
    }

    // Pattern D: Pyramid [cite: 3-7]
    printf("\nPattern D:\n");
    for(i=1; i<=n; i++) {
        for(j=1; j<=n-i; j++) printf(" ");
        for(k=1; k<=(2*i-1); k++) printf("*");
        printf("\n");
    }

    // Pattern E: Hollow C-Shape [cite: 8-14]
    printf("\nPattern E:\n");
    for(i=1; i<=n; i++) {
        for(j=1; j<=n; j++) {
            if(i == 1 || i == n || j == 1||j==n) 
                printf("*");
            else 
                printf(" ");
        }
        printf("\n");
    }

    // Pattern F: Floyd's Triangle [cite: 15-19]
    n = 4;
    int count = 1;
    printf("\nPattern F:\n");
    for(i=1; i<=n; i++) {
        for(j=1; j<=i; j++) {
            printf("%d ", count++);
        }
        printf("\n");
    }

    // Pattern G: Vertical Column Filling [cite: 20-24]
    // 1
    // 2 5
    // 3 6 8
    // 4 7 9 10
    n = 4;
    printf("\nPattern G:\n");
    for(i=1; i<=n; i++) {
        int val = i;
        int diff = n - 1;
        for(j=1; j<=i; j++) {
            printf("%d ", val);
            val = val + diff;
            diff--;
        }
        printf("\n");
    }

    return 0;
}