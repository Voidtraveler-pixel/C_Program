#include <stdio.h>
int main() {
    int n, i, choice;
    float marks[100], sum = 0, max, min;
    int passedCount = 0;
    printf("Enter number of students (N): ");
    scanf("%d", &n);
    printf("Enter marks for %d students:\n", n);
    for(i = 0; i < n; i++) 
    {
        printf("Student %d: ", i + 1);
        scanf("%f", &marks[i]);
    }
        printf("\n--- Student Result Analyzer ---\n");
        printf("1. Display Total and Average Marks\n");
        printf("2. Find Highest and Lowest Marks\n");
        printf("3. Count Students Passed (Marks >= 40)\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch(choice) 
        {
            case 1: 
                sum = 0;
                for(i = 0; i < n; i++) sum += marks[i];
                printf("Total Marks: %.2f\n", sum);
                printf("Average Marks: %.2f\n", sum / n);
                break;
            case 2: 
                max = marks[0];
                min = marks[0];
                for(i = 1; i < n; i++) 
                {
                    if(marks[i] > max) max = marks[i];
                    if(marks[i] < min) min = marks[i];
                }
                printf("Highest Marks: %.2f\n", max);
                printf("Lowest Marks: %.2f\n", min);
                break;
            case 3: 
                passedCount = 0;
                for(i = 0; i < n; i++) {
                    if(marks[i] >= 40) passedCount++;
                }
                printf("Number of Students Passed: %d\n", passedCount);
                break;
            case 4: // Exit [cite: 32]
                printf("Exiting program...\n");
                break;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    return 0;
}