#include <stdio.h>

int main() 
{
    int n, i, even = 0, odd = 0;
    printf("Enter N: ");
    scanf("%d", &n);
    for(i = 1; i <= n; i++) 
    {
        if(i % 2 == 0)
            even = even + i;
        else
            odd = odd + i;
    }
    printf("Sum of Even numbers: %d \n", even);
    printf("Sum of Odd numbers: %d \n", odd);
    return 0;
}