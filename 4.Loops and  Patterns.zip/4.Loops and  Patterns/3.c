#include <stdio.h>

int main() 
{
    int base,exp,i;
    int result = 1;
    printf("Enter base (x) and exponent (y): ");
    scanf("%d %d", &base, &exp);
    for(i = 1; i <= exp; i++) 
    {
        result = result * base;
    }

    printf("%d^%d = %d\n", base, exp, result);
    return 0;
}