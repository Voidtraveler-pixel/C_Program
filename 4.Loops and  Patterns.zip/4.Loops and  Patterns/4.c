#include <stdio.h>

int main() 
{
    int n, i, count = 0;
    printf("Enter a number: ");
    scanf("%d", &n);
    printf("Divisors: ");
    for(i = 1; i <= n; i++) 
    {
        if(n % i == 0) 
        {
            printf("%d ", i);
            count++;
        }
    }
    printf("\nTotal factors: %d\n", count);
    return 0;
}