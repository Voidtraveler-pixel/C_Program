#include <stdio.h>

int main()
{
    int n, i, evenCount = 0, oddCount = 0;
    int arr[100];
    printf("Enter number of elements: ");
    scanf("%d", &n);
    printf("Enter %d integers:\n", n);
    for(i = 0; i < n; i++) 
    {
        scanf("%d", &arr[i]);
        if(arr[i] % 2 == 0)
        {
            evenCount++;
        } 
        else 
        {
            oddCount++;
        }
    }
    printf("Total Even numbers: %d\n", evenCount);
    printf("Total Odd numbers: %d\n", oddCount);
    return 0;
}