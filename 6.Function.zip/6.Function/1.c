#include <stdio.h>

void printWelcome() 
{
    printf("Welcome to C Programming!\n");
}

int main() 
{
    printWelcome();
    return 0;
}