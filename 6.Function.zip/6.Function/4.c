#include <stdio.h>
long calculate(int n);
int main() 
{
    int num;
    long fact;
    printf("Enter a positive integer: ");
    scanf("%d", &num);
    if (num < 0) 
    {
        printf("Error.\n");
    } 
    else 
    {
        fact = calculate(num);
        printf("Factorial of %d = %ld\n", num, fact);
    }
    return 0;
}
long calculate(int n) 
{
    long result = 1;
    for (int i = 1; i <= n; i++) 
    {
        result *= i;
    } 
    return result;
}
