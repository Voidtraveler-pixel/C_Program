#include <stdio.h>

void print1toN(int n)
{
    if (n == 0) 
    {
        return;
    }
    print1toN(n - 1); 
    printf("%d ", n);
}
int main() 
{
    int N;
    printf("Enter N: ");
    scanf("%d", &N);
    printf("Numbers from 1 to %d: ", N);
    print1toN(N);
    printf("\n");
    return 0;
}