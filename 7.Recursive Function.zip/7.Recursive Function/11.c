#include <stdio.h>

int linearSearch(int a[], int s, int k, int i) 
{
    if (i >= s) 
    {
        return -1; 
    }
    if (a[i] == k) 
    {
        return i; 
    }
    return linearSearch(a, s, k, i+1);
}
int main() 
{
    int a[] = {12, 34, 54, 2, 3};
    int k, r;
    int s= sizeof(a) / sizeof(a[0]);
    
    printf("Enter element to search: ");
    scanf("%d", &k);
    
    r = linearSearch(a, s, k, 0);
    
    if (r!= -1) 
    {
        printf("Element found at index: %d\n", r);
    } 
    else 
    {
        printf("Element not found.\n");
    }
    return 0;
}