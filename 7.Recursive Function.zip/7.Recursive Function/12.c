#include <stdio.h>

int binarySearch(int arr[], int low, int high, int key) 
{
    if (low > high) 
    {
        return -1; 
    }
    int mid = low + (high - low)/2; 
    if (arr[mid] == key) 
    {
        return mid; 
    }
    else if (arr[mid]>key) 
    {
        return binarySearch(arr, low, mid - 1, key);
    }
    else 
    {
        return binarySearch(arr, mid + 1, high, key);
    }
}
int main() 
{
    int arr[] = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};
    int key, result;
    int size = sizeof(arr) / sizeof(arr[0]);
    printf("Sorted Array: ");
    for(int i=0; i<size; i++) printf("%d ", arr[i]);
    printf("\n");
    printf("Enter element to search: ");
    scanf("%d", &key);
    result = binarySearch(arr, 0, size - 1, key);
    if (result != -1) 
    {
        printf("Element found at index: %d\n", result);
    } 
    else 
    {
        printf("Element not found.\n");
    }
    return 0;
}