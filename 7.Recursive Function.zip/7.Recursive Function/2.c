#include <stdio.h>

void printNto1(int n) 
{
    if (n == 0) 
    {
        return;
    }
    printf("%d ", n); 
    printNto1(n - 1);
}
int main() 
{
    int N;
    printf("Enter N: ");
    scanf("%d", &N);
    printf("Numbers from %d to 1: ", N);
    printNto1(N);
    printf("\n");
    return 0;
}