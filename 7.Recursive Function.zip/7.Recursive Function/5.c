#include <stdio.h>

long int factorial(int n) 
{
    if (n == 0 || n == 1) 
    {
        return 1;
    }
    return n * factorial(n - 1);
}
int main() 
{
    int N;
    printf("Enter a number: ");
    scanf("%d", &N);
    printf("Factorial of %d is: %ld\n", N, factorial(N));
    return 0;
}