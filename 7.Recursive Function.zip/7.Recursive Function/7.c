#include <stdio.h>

int reverseNumber(int num, int rev) 
{
    if (num == 0) 
    {
        return rev;
    }
    return reverseNumber(num / 10, rev * 10 + (num % 10));
}

int main() {
    int n, reversed;
    printf("Enter a number: ");
    scanf("%d", &n);
    reversed = reverseNumber(n, 0);
    
    if (n == reversed) 
    {
        printf("%d is a Palindrome.\n", n);
    } 
    else 
    {
        printf("%d is NOT a Palindrome.\n", n);
    }
    return 0;
}