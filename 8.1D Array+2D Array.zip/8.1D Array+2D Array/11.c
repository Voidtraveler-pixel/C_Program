#include <stdio.h>

int main() 
{
    int r1, c1, r2, c2, i, j, k;
    
    printf("Enter rows and columns for 1st matrix: ");
    scanf("%d %d", &r1, &c1);
    printf("Enter rows and columns for 2nd matrix: ");
    scanf("%d %d", &r2, &c2);
  
    if(c1 != r2) 
    {
        printf("Error: Multiplication not possible. Columns of 1st must equal Rows of 2nd.\n");
        return 1;
    }
    
    int mat1[r1][c1], mat2[r2][c2], result[r1][c2];
 
    printf("Enter elements of 1st matrix:\n");
    for(i = 0; i < r1; i++) 
    {
        for(j = 0; j < c1; j++) 
        {
            scanf("%d", &mat1[i][j]);
        }
    }
      
    printf("Enter elements of 2nd matrix:\n");
    for(i = 0; i < r2; i++) 
    {
        for(j = 0; j < c2; j++) 
        {
            scanf("%d", &mat2[i][j]);
        }
    }
    
    for(i = 0; i < r1; i++) 
    {
        for(j = 0; j < c2; j++) 
        {
            result[i][j] = 0;

            for(k = 0; k < c1; k++) 
            {
                result[i][j] += mat1[i][k] * mat2[k][j];
            }
        }
    }
    
    printf("Resultant matrix after multiplication:\n");
    for(i = 0; i < r1; i++) 
    {
        for(j = 0; j < c2; j++) 
        {
            printf("%d\t", result[i][j]);
        }
        printf("\n");
    }
    return 0;
}