#include <stdio.h>

int main()
{
    int n, i, j, sum = 0;
    
    printf("Enter the size of the square matrix (N x N): ");
    scanf("%d", &n);
    
    int mat[n][n];
 
    printf("Enter matrix elements:\n");
    for(i = 0; i < n; i++) 
    {
        for(j = 0; j < n; j++) 
        {
            scanf("%d", &mat[i][j]);
        }
    }
    
    printf("\nPrincipal diagonal elements: ");
    for(i = 0; i < n; i++) 
    {
        printf("%d ", mat[i][i]);
        sum += mat[i][i];
    }
    
    printf("\nSum of principal diagonal elements = %d\n", sum);
    return 0;
}