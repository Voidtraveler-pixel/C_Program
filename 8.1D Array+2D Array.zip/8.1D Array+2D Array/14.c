#include <stdio.h>

int main() 
{
    int n, m, i, j;
    
    printf("Enter number of students (N): ");
    scanf("%d", &n);
    printf("Enter number of subjects (M): ");
    scanf("%d", &m);
   
    int marks[n][m];
    
    for(i = 0; i < n; i++) 
    {
        printf("\nEnter marks for Student %d in %d subjects:\n", i + 1, m);
        for(j = 0; j < m; j++) 
        {
            printf("Subject %d: ", j + 1);
            scanf("%d", &marks[i][j]);
        }
    }

    printf("\n--- Final Results ---\n");
    for(i = 0; i < n; i++)
    {
        int total = 0;
        for(j = 0; j < m; j++) 
        {
            total += marks[i][j];
        }
        float average = (float)total / m;
        printf("Student %d -> Total Marks: %d, Average: %.2f\n", i + 1, total, average);
    }
    
    return 0;
}