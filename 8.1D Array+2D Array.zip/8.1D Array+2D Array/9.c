#include <stdio.h>

int main() 
{
    int r, c, i, j;
    printf("Enter number of rows and columns for matrices: ");
    scanf("%d %d", &r, &c);
    
    int mat1[r][c], mat2[r][c], sum[r][c];
    
    printf("Enter elements of 1st matrix:\n");
    for(i = 0; i < r; i++)
    {
        for(j = 0; j < c; j++) 
        {
            scanf("%d", &mat1[i][j]);
        }
    }
    
    printf("Enter elements of 2nd matrix:\n");
    for(i = 0; i < r; i++)
    {
        for(j = 0; j < c; j++)
        {
            scanf("%d", &mat2[i][j]);
        }
    }

    printf("Sum of matrices:\n");
    for(i = 0; i < r; i++) 
    {
        for(j = 0; j < c; j++) 
        {
            sum[i][j] = mat1[i][j] + mat2[i][j];
            printf("%d\t", sum[i][j]);
        }
        printf("\n");
    }
    return 0;
}