#include <stdio.h>
//#include<string.h>
int mystrlen(char []);
void mystrcpy(char [],char []);
int mystrcmp(char [],char []);
void strsort(char a[10][100],int n);

int main() 
{
    char a[100],b[100],c[100],name[10][100];
    int l,n,i;
    fflush(stdin);
    printf("\nEnter first string:");
 //   scanf("%[^\n]",a);
  // gets(a);   fgets(a,100,stdin);
    
    l=mystrlen(a);
    printf("You have entered:%s and length=%d",a,l);
    
    mystrcpy(b,a);
    printf("\n The copied string =%s",b);
    
    fflush(stdin);
    printf("\nEnter second string:");
    scanf("%[^\n]",c);
   
    l=mystrcmp(a,c);
    if(l==0)
    printf("\n Both strings are equal");
    else
    printf("\n Both strings are not equal =%d",l);
    
    printf("\nHow many name?:");
    scanf("%d",&n);
    fflush(stdin);
    printf("\nEnter %d names ",n);
    for(i=0;i<n;i++)
   fgets(name[i],100,stdin);
    
    strsort(name,n);
    printf("\nAfter sort the names are:\n");
       for(i=0;i<n;i++)
    printf("\n%d. %s",i+1,name[i]);
    return 0;
}

void strsort(char name[10][100], int n)
    {
        int i,j;
        char temp[100];
        for(i=0;i<n-1;i++)
            {
                for(j=0;j<n-i-1;j++)
                    {
                        if(mystrcmp(name[j],name[j+1])>0)
                            {
                                mystrcpy(temp,name[j]);
                                mystrcpy(name[j],name[j+1]);
                                mystrcpy(name[j+1],temp);
                            }
                    }
            }
    }
    
int mystrlen(char a[])
    {
        int i;
        
        for(i=0;a[i]!='\0';i++);
        
        return i-1;
    }
void mystrcpy(char d[],char s[])
    {
        int i;
        
        for(i=0;s[i]!='\0';i++)
            {
                d[i]=s[i];
            }
        d[i]='\0';
    }
int mystrcmp(char s1[],char s2[])
    {
        int i;
   
    for(i=0;s1[i]!='\0'||s2[i]!='\0';i++)
    
        {
            if(s1[i]!=s2[i])
                {
                    return (s1[i]-s2[i]);
                }
        }
    return 0;
    }